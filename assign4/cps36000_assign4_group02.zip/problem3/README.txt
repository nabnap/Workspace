/******************************************************************************
Title: 				Address Manager
Author: 			Robert Dudasik, Nick Biegel, Ethan Blatti
Created on: 			November 27th, 2016
Description: 			A program that stores a person's name and address
Purpose: 			Demonstrate knowledge of MFC by creating a GUI for a program that stores data
Usage: 				Select an option and query for people or create entries for new people
				Unfortunately, there was difficulty storing the data in this program and passing it between forms.
Build with: 			Visual Studio 2015
Modifications:			None
******************************************************************************/
