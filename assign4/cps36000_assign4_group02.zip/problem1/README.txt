/******************************************************************************
Title:				Fancy Clock Program
Author:				Ethan Blatti, Nick Biegel, Robert Dudasik
Created on:			November 20, 2016
Description:		Displays the time in 12 hour format in the color of your choice.
Purpose:			Demonstrate knowledge of QT.
Usage:				Right click on a lcd number on the clock to exit the program or choose option to change the color.
Build with:			Qt Creator
Modifications:		None
******************************************************************************/