/******************************************************************************
Title:				Sketcher Program
Author:				Ethan Blatti, Nick Biegel, Robert Dudasik
Created on:			November 20, 2016
Description:		Allows you to change shape type and color for sketching.
Purpose:			Demonstrate knowledge of MFC menu.
Usage:				Select shape and color on the menu bar.
Build with:			Visual Studio 2015
Modifications:		None
******************************************************************************/