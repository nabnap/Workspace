/******************************************************************************
Title:				Phonebook Program
Author:				Ethan Blatti, Nick Biegel, Robert Dudasik
Created on:			November 20, 2016
Description:		Allows you to add contacts for future reference.
Purpose:			Demonstrate knowledge of QT.
Usage:				Click Add to add a contact or select a contact from the list and delete it. 
Build with:			Qt Creator
Modifications:		None
******************************************************************************/